export class Author {
    id: number;
    fullName: string;
    biography: string;
    user_id: number;
}
