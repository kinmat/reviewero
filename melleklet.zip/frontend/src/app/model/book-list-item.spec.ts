import { BookListItem } from './book-list-item';

describe('BookListItem', () => {
  it('should create an instance', () => {
    expect(new BookListItem()).toBeTruthy();
  });
});
