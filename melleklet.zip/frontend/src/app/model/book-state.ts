export class BookState {
    id: number;
    name: string;
}
