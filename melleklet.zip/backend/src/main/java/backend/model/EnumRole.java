package backend.model;

public enum EnumRole {
	ROLE_USER,
	ADMIN,
	AUTHOR,
	REVIEWER
}
