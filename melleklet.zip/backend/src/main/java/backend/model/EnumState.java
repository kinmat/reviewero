package backend.model;

public enum EnumState {
	to_read,
	read
}