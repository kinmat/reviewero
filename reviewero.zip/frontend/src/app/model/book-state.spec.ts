import { BookState } from './book-state';

describe('BookState', () => {
  it('should create an instance', () => {
    expect(new BookState()).toBeTruthy();
  });
});
