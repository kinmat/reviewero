import { Friendship } from './friendship';

describe('Friendship', () => {
  it('should create an instance', () => {
    expect(new Friendship()).toBeTruthy();
  });
});
