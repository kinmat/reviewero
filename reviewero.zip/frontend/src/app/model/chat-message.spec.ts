import { ChatMessage } from './chat-message';

describe('ChatMessage', () => {
  it('should create an instance', () => {
    expect(new ChatMessage()).toBeTruthy();
  });
});
